<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFormsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('forms', function (Blueprint $table) {
            $table->id();
            //$table->integer('vendor_id')->unsigned()->index();
            $table->foreignId('vendor_id')->constrained()->onDelete('cascade');
                $table->unique('vendor_id');
            $table->string('address');
            $table->string('country');
            $table->string('state');
            $table->string('city');
            $table->string('zipcode');
            $table->string('primaryContact');
            $table->string('primaryEmail');
            $table->string('primaryTelephone');
            $table->string('primaryMobile');
            $table->string('primaryFax');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('forms');
    }
}
