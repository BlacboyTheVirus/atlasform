<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign In</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap-4.6.0-dist/css/bootstrap.min.css')); ?>">
</head>
<body>

    <div class = "container">
        <div class="row" style="margin-top: 45px">
            <div class="col-md-4 col-md-offset-4">
                <h4>Login</h4><hr>
                <form action="" method="post">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" class="form-control" name="email" placeholder="Enter email address">
                    </div>

                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" name="email" placeholder="Enter password">
                    </div>

                    <button type="submit" class="btn btn-block btn-primary">Register</button>

                    <br>
                    <a href="<?php echo e(route('auth.register')); ?>">Register</a>

                </form>
            </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH D:\dev\atlasform\resources\views/login.blade.php ENDPATH**/ ?>